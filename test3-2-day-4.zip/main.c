/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int rec(int);
int main()
{
    int a;
    printf("enter the number:");
    scanf("%d",&a);
    printf("the factorial of %d=%d",a,rec(a));
    return 0;
}
int rec(int x)
{
    int f;
    if(x==1)
    return 1;
    else
    f=x*rec(x-1);
    return f;
}
