/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include<stdio.h>
int main()
{
    double a,b,temp;
    printf("enter the first number:");
    scanf("%lf",&a);
    printf("enter the second number:");
    scanf("%lf",&b);
    printf("enter the third number");
    scanf("%lf",&temp);
    temp=a;
    a=b;
    b=temp;
    printf("\nAfter swapping, first number = %.2lf\n", a);
    printf("After swapping, second number = %.lf", b);
  return 0;
}
    
    

